from hoshino.service import Service
from .data import schedule
from nonebot import get_bot, scheduler
import os
import hoshino
imgpath = os.path.join(os.path.dirname(__file__), 'pic.png')
bot = get_bot()
sid = '2829259368'
groupid = '874488430'
@scheduler.scheduled_job('cron', minute='*/3')
async def school_activity():
    with open (os.path.join(os.path.dirname(__file__), 'local.txt') , "r", encoding='utf-8') as f:
        data = f.read()
    webdata = schedule()
    if webdata != data:
        f.close()
        with open (os.path.join(os.path.dirname(__file__), 'local.txt') , "w", encoding='utf-8') as g:
            g.write(webdata)
            g.close()
            master_id = hoshino.config.SUPERUSERS[0]
            #login_id = await bot.get_login_info()
            #sid = login_id['user_id']
            await bot.send_group_msg(self_id=sid,group_id=groupid,message=f'[CQ:image,file=file:///{imgpath}]')
    else:
        f.close()