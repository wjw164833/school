import sys
import io
from selenium import webdriver
import time
from selenium.webdriver.chrome.options import Options
import os

chrome_options =Options()
chrome_options.add_argument('--headless')
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def schedule():
    browser = webdriver.Chrome(options=chrome_options)
    browser.set_window_size(550,600)
    browser.get('http://a.cqie.edu.cn/cas/login')
    browser.implicitly_wait(5)

    username = browser.find_element_by_id('username')

    username.send_keys('你的学号')
    browser.implicitly_wait(5)
    password = browser.find_element_by_id('password')
    password.send_keys('密码')

    login_button = browser.find_element_by_link_text('登录')
    login_button.click()
    time.sleep(5)
    browser.get('http://xs.cqie.edu.cn/xg/allhdzyz/FromQXHDMHViewMH')
    browser.get('http://xs.cqie.edu.cn/xg/allhdzyz/FromQXHDMHViewMH')
    time.sleep(5)
    browser.save_screenshot(os.path.join(os.path.dirname(__file__), 'pic.png'))
    html = browser.page_source
    browser.quit()
    return html
    
    