# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import requests
import json
from bs4 import BeautifulSoup
import re
from openpyxl import load_workbook
import openpyxl
import sys
import io
from selenium import webdriver
import time
from selenium.webdriver.chrome.options import Options
import os

chrome_options =Options()
chrome_options.add_argument('--headless')
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def schedule(name,passs):
    browser = webdriver.Chrome(options=chrome_options)
    browser.set_window_size(550, 600)
    browser.get('http://a.cqie.edu.cn/cas/login')
    browser.implicitly_wait(5)

    username = browser.find_element_by_id('username')

    username.send_keys(name)
    browser.implicitly_wait(5)
    password = browser.find_element_by_id('password')
    password.send_keys(passs)

    login_button = browser.find_element_by_link_text('登录')
    login_button.click()
    time.sleep(5)
    browser.get('http://xs.cqie.edu.cn/xg/allhdzyz/FromQXHDMHViewMH')
    browser.get('http://xs.cqie.edu.cn/xg/allhdzyz/FromQXHDMHViewMH')
    time.sleep(5)
    cookie =browser.get_cookies()[0]['value']
    # browser.save_screenshot(os.path.join(os.path.dirname(__file__), 'pic.png'))
    # html = browser.page_source
    # browser.quit()
    # return html
    wb1 = openpyxl.Workbook()
    wb2 = openpyxl.Workbook()
    wb1.save(name + "线上.xlsx")
    wb2.save(name + "线下.xlsx")

    workbook = load_workbook(filename=name + '线上.xlsx')
    xians = workbook.active
    workbook1 = load_workbook(filename=name + '线下.xlsx')
    xianx = workbook1.active
    nb = []
    weijf = []
    xxia = []

    a = 0
    b = 0
    c = 0
    d = 0
    a1 = 0
    b1 = 0
    c1 = 0
    d1 = 0
    a_1 = 0
    b_1 = 0
    c_1 = 0
    d_1 = 0
    a1_1 = 0
    b1_1 = 0
    c1_1 = 0
    d1_1 = 0

    def implicitly_wait(param):
        pass

    for i in range(1, 9):
        cs = fs(str(i), cookie)
        nb = nb + cs[0]
        weijf = weijf + cs[1]
        implicitly_wait(10)  # 设置等待时间

    print(len(nb))
    for i in range(1, 10):
        xxia = xxia + xx(str(i), cookie)
        implicitly_wait(10)  # 设置等待时间
    print(len(xxia))

    j = 1
    x = 4
    while x < len(nb):
        if nb[x] == '第一学期':
            if nb[x - 3] == 'A':
                a = a + int(nb[x - 2])
            else:
                if nb[x - 3] == 'B':
                    b = b + int(nb[x - 2])
                else:
                    if nb[x - 3] == 'C':
                        c = c + int(nb[x - 2])
                    else:
                        if nb[x - 3] == 'D':
                            d = d + int(nb[x - 2])
        else:
            if nb[x - 3] == 'A':
                a1 = a1 + int(nb[x - 2])
            else:
                if nb[x - 3] == 'B':
                    b1 = b1 + int(nb[x - 2])
                else:
                    if nb[x - 3] == 'C':
                        c1 = c1 + int(nb[x - 2])
                    else:
                        if nb[x - 3] == 'D':
                            d1 = d1 + int(nb[x - 2])
        xians['A' + str(j)].value = nb[x - 4]
        xians['B' + str(j)].value = nb[x - 3]
        xians['C' + str(j)].value = nb[x - 2]
        xians['D' + str(j)].value = nb[x - 1]
        xians['E' + str(j)].value = nb[x]
        xians['F' + str(j)].value = '完成'
        j = j + 1
        x = x + 5

    x = 4
    while x < len(weijf):
        xians['A' + str(j)].value = weijf[x - 4]
        xians['B' + str(j)].value = weijf[x - 3]
        xians['C' + str(j)].value = weijf[x - 2]
        xians['D' + str(j)].value = weijf[x - 1]
        xians['E' + str(j)].value = weijf[x]
        xians['F' + str(j)].value = '未完成'
        j = j + 1
        x = x + 5
    j = 1
    i = 2
    while i < len(xxia):
        if xxia[i] == '第一学期':
            if xxia[i + 1] == 'A':
                a_1 = a_1 + int(xxia[i + 2])
            else:
                if xxia[i + 1] == 'B':
                    b_1 = b_1 + int(xxia[i + 2])
                else:
                    if xxia[i + 1] == 'C':
                        c_1 = c_1 + int(xxia[i + 2])
                    else:
                        if xxia[i + 1] == 'D':
                            d_1 = d_1 + int(xxia[i + 2])
        else:
            if xxia[i + 1] == 'A':
                a1_1 = a1_1 + int(xxia[i + 2])
            else:
                if xxia[i + 1] == 'B':
                    b1_1 = b1_1 + int(xxia[i + 2])
                else:
                    if xxia[i + 1] == 'C':
                        c1_1 = c1_1 + int(xxia[i + 2])
                    else:
                        if xxia[i + 1] == 'D':
                            d1_1 = d1_1 + int(xxia[i + 2])
        xianx['A' + str(j)].value = xxia[i - 2]
        xianx['B' + str(j)].value = xxia[i - 1]
        xianx['C' + str(j)].value = xxia[i]
        xianx['D' + str(j)].value = xxia[i + 1]
        xianx['E' + str(j)].value = xxia[i + 2]
        j = j + 1
        i = i + 5

    print('线上活动')
    print('第一学期')
    print(a, b, c, d)
    print('第二学期')
    print(a1, b1, c1, d1)

    er = int((len(nb) + len(weijf)) / 5)

    xians['A' + str(er + 1)].value = '学期'
    xians['B' + str(er + 1)].value = 'A'
    xians['C' + str(er + 1)].value = 'B'
    xians['D' + str(er + 1)].value = 'C'
    xians['E' + str(er + 1)].value = 'D'
    xians['A' + str(er + 2)].value = '第一学期'
    xians['B' + str(er + 2)].value = a
    xians['C' + str(er + 2)].value = b
    xians['D' + str(er + 2)].value = c
    xians['E' + str(er + 2)].value = d
    xians['A' + str(er + 3)].value = '第二学期'
    xians['B' + str(er + 3)].value = a1
    xians['C' + str(er + 3)].value = b1
    xians['D' + str(er + 3)].value = c1
    xians['E' + str(er + 3)].value = d1
    print('线下活动')
    print('第一学期')
    print(a_1, b_1, c_1, d_1)
    print('第二学期')
    print(a1_1, b1_1, c1_1, d1_1)

    er = int(len(xxia) / 5)
    xianx['A' + str(er + 1)].value = '学期'
    xianx['B' + str(er + 1)].value = 'A'
    xianx['C' + str(er + 1)].value = 'B'
    xianx['D' + str(er + 1)].value = 'C'
    xianx['E' + str(er + 1)].value = 'D'
    xianx['A' + str(er + 2)].value = '第一学期'
    xianx['B' + str(er + 2)].value = a_1
    xianx['C' + str(er + 2)].value = b_1
    xianx['D' + str(er + 2)].value = c_1
    xianx['E' + str(er + 2)].value = d_1
    xianx['A' + str(er + 3)].value = '第二学期'
    xianx['B' + str(er + 3)].value = a1_1
    xianx['C' + str(er + 3)].value = b1_1
    xianx['D' + str(er + 3)].value = c1_1
    xianx['E' + str(er + 3)].value = d1_1

    print("素质学分换算得分")
    print('第一学期：')
    print(xf(a + a_1, b + b_1, c + c_1, d + d_1))
    print('第二学期：')
    print(xf(a1 + a1_1, b1 + b1_1, c1 + c1_1, d1 + d1_1))
    workbook.save(filename=name + '线上.xlsx')
    workbook1.save(filename=name + '线下.xlsx')
    os.system('pause')


# 通过查看详情查看分数
def nx(data1, cookies):
    cookies = {
        'JSESSIONID': cookies,
    }
    headers = {
        'Connection': 'keep-alive',
        'Accept': 'text/html, */*; q=0.01',
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 Edg/90.0.818.62',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Origin': 'http://xs.cqie.edu.cn',
        'Referer': 'http://xs.cqie.edu.cn/xg/backstageNoNav.jsp?loadMainPage=spring:allhdzyz/FromQXHDMHView',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }

    data = {
        'dataId': data1
    }
    response = requests.post('http://xs.cqie.edu.cn/xg/allhdzyz/FromHDSQView', headers=headers,
                             cookies=cookies, data=data, verify=False)
    res = response.text
    soup = BeautifulSoup(res, features="html.parser")
    x = soup.script.string
    # print(x)
    y = re.search("var data = (.*);", x)
    z = y.group(1)
    # print(z)
    js_test = json.loads(z)
    hd = []
    hd.append(js_test['HDSX'])  # 分数
    hd.append(js_test['HDXQ'])  # 学期
    # print(hd)
    return hd


# 类型分析
def lx(b):
    s = ''
    if b == '301':
        s = 'A'
    else:
        if b == '302':
            s = 'B'
        else:
            if b == '303':
                s = 'C'
            else:
                if b == '304':
                    s = 'D'
    return s


# 线上活动数据处理
def sjcl(i, cookie):
    nb = []
    ks_sj = "开始时间：" + i['HDKSSJ']
    js_sj = "结束时间：" + i['HDJSSJ']
    hd_mc = "活动名称：" + i['HDMC']
    hd_bh = "活动编号：" + i['FQZDH']
    hd_sf = i['RU']
    hd_id = i['ID']
    hd_fs = "分数：" + i['HDXF']
    hd_rs = "可申请人数：" + i['ZMRS']
    hd_dw = "举办单位：" + i['FQDW']
    # print(ks_sj, js_sj, hd_mc, hd_bh, "活动排序：", hd_sf, "活动id：", hd_id, hd_fs, hd_rs, hd_dw)
    b = nx(i['ID'], cookie)
    # print(b)
    nb.append(hd_mc)
    nb.append(lx(b[0]))
    nb.append(i['HDXF'])
    # startTime = time.mktime(time.strptime(i['HDKSSJ'], '%Y-%m-%d %H:%M'))
    # star = time.mktime(time.strptime('2020-08-01 01:00', '%Y-%m-%d %H:%M'))
    # star1 = time.mktime(time.strptime('2021-02-15 01:00', '%Y-%m-%d %H:%M'))

    # nb.insert(y + 3, startTime)
    nb.append(i['HDKSSJ'])
    # if star <= startTime and startTime <= star1:
    if b[1] == '01':
        nb.append('第一学期')
    else:
        nb.append('第二学期')
    return nb


# 查看所有申请的活动
def fs(type, cookie):
    cookies = {
        'JSESSIONID': cookie,
    }
    headers = {
        'Connection': 'keep-alive',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 Edg/90.0.818.62',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': 'http://xs.cqie.edu.cn/xg/backstageNoNav.jsp?loadMainPage=spring:allhdzyz/FromQXHDMHView',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }
    params = (
        ('curPage', type),
        ('type', '2'),
    )
    response = requests.get('http://xs.cqie.edu.cn/xg/allhdzyz/queryQXHDMH', headers=headers, params=params,
                            cookies=cookies, verify=False)
    js = response.json()
    # print(js)
    content = json.dumps(js, ensure_ascii=False)
    result = json.loads(content)  # json.load()是用来读取文件的
    hd = result['data']
    nb = []
    nd = []
    nc = []
    # print(hd)
    for i in hd:
        if i['SFWCHD'] == '1':
            nb = nb + sjcl(i, cookie)
        else:
            nd = nd + sjcl(i, cookie)
    nc.append(nb)  # 加分
    nc.append(nd)  # 未加分
    return nc


# 线下活动
def xx(sz, cookie):
    cookies = {
        'JSESSIONID': cookie,
    }

    headers = {
        'Connection': 'keep-alive',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36 Edg/90.0.818.62',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': 'http://xs.cqie.edu.cn/xg/backstageNoNav.jsp?loadMainPage=spring:allhdzyz/FromQXHDMHView',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    }

    params = (
        ('curPage', sz),
        ('type', '3'),
    )

    response = requests.get('http://xs.cqie.edu.cn/xg/allhdzyz/queryQXHDMH', headers=headers, params=params,
                            cookies=cookies, verify=False)
    js = response.json()
    x = js['data']
    y = ''
    nb = []
    for i in x:
        if i['HDLB'] == '301':
            y = 'A'
        else:
            if i['HDLB'] == '302':
                y = 'B'
            else:
                if i['HDLB'] == '303':
                    y = 'C'
                else:
                    if i['HDLB'] == '304':
                        y = 'D'
        nb.append(i['HDMC'])
        nb.append(i['HDXN'])
        if i['HDXQ'] == '01':
            nb.append('第一学期')
        else:
            nb.append('第二学期')
        nb.append(y)
        nb.append(i['HDXS'])
    return nb


def xf(a, b, c, d):
    if a >= 100:
        a = 100
    if b >= 100:
        b = 100
    if c >= 100:
        c = 100
    if d >= 100:
        d = 100
    print(a, b, c, d)
    return a * 0.35 + b * 0.3 + c * 0.2 + d * 0.15


def ks(name, cookie):
    wb1 = openpyxl.Workbook()
    wb2 = openpyxl.Workbook()
    wb1.save(name + "线上.xlsx")
    wb2.save(name + "线下.xlsx")

    workbook = load_workbook(filename=name + '线上.xlsx')
    xians = workbook.active
    workbook1 = load_workbook(filename=name + '线下.xlsx')
    xianx = workbook1.active
    nb = []
    weijf = []
    xxia = []

    a = 0
    b = 0
    c = 0
    d = 0
    a1 = 0
    b1 = 0
    c1 = 0
    d1 = 0
    a_1 = 0
    b_1 = 0
    c_1 = 0
    d_1 = 0
    a1_1 = 0
    b1_1 = 0
    c1_1 = 0
    d1_1 = 0

    def implicitly_wait(param):
        pass

    for i in range(1, 9):
        cs = fs(str(i), cookie)
        nb = nb + cs[0]
        weijf = weijf + cs[1]
        implicitly_wait(10)  # 设置等待时间

    print(len(nb))
    for i in range(1, 10):
        xxia = xxia + xx(str(i), cookie)
        implicitly_wait(10)  # 设置等待时间
    print(len(xxia))

    j = 1
    x = 4
    while x < len(nb):
        if nb[x] == '第一学期':
            if nb[x - 3] == 'A':
                a = a + int(nb[x - 2])
            else:
                if nb[x - 3] == 'B':
                    b = b + int(nb[x - 2])
                else:
                    if nb[x - 3] == 'C':
                        c = c + int(nb[x - 2])
                    else:
                        if nb[x - 3] == 'D':
                            d = d + int(nb[x - 2])
        else:
            if nb[x - 3] == 'A':
                a1 = a1 + int(nb[x - 2])
            else:
                if nb[x - 3] == 'B':
                    b1 = b1 + int(nb[x - 2])
                else:
                    if nb[x - 3] == 'C':
                        c1 = c1 + int(nb[x - 2])
                    else:
                        if nb[x - 3] == 'D':
                            d1 = d1 + int(nb[x - 2])
        xians['A' + str(j)].value = nb[x - 4]
        xians['B' + str(j)].value = nb[x - 3]
        xians['C' + str(j)].value = nb[x - 2]
        xians['D' + str(j)].value = nb[x - 1]
        xians['E' + str(j)].value = nb[x]
        xians['F' + str(j)].value = '完成'
        j = j + 1
        x = x + 5

    x = 4
    while x < len(weijf):
        xians['A' + str(j)].value = weijf[x - 4]
        xians['B' + str(j)].value = weijf[x - 3]
        xians['C' + str(j)].value = weijf[x - 2]
        xians['D' + str(j)].value = weijf[x - 1]
        xians['E' + str(j)].value = weijf[x]
        xians['F' + str(j)].value = '未完成'
        j = j + 1
        x = x + 5
    j = 1
    i = 2
    while i < len(xxia):
        if xxia[i] == '第一学期':
            if xxia[i + 1] == 'A':
                a_1 = a_1 + int(xxia[i + 2])
            else:
                if xxia[i + 1] == 'B':
                    b_1 = b_1 + int(xxia[i + 2])
                else:
                    if xxia[i + 1] == 'C':
                        c_1 = c_1 + int(xxia[i + 2])
                    else:
                        if xxia[i + 1] == 'D':
                            d_1 = d_1 + int(xxia[i + 2])
        else:
            if xxia[i + 1] == 'A':
                a1_1 = a1_1 + int(xxia[i + 2])
            else:
                if xxia[i + 1] == 'B':
                    b1_1 = b1_1 + int(xxia[i + 2])
                else:
                    if xxia[i + 1] == 'C':
                        c1_1 = c1_1 + int(xxia[i + 2])
                    else:
                        if xxia[i + 1] == 'D':
                            d1_1 = d1_1 + int(xxia[i + 2])
        xianx['A' + str(j)].value = xxia[i - 2]
        xianx['B' + str(j)].value = xxia[i - 1]
        xianx['C' + str(j)].value = xxia[i]
        xianx['D' + str(j)].value = xxia[i + 1]
        xianx['E' + str(j)].value = xxia[i + 2]
        j = j + 1
        i = i + 5

    print('线上活动')
    print('第一学期')
    print(a, b, c, d)
    print('第二学期')
    print(a1, b1, c1, d1)

    er = int((len(nb) + len(weijf)) / 5)

    xians['A' + str(er + 1)].value = '学期'
    xians['B' + str(er + 1)].value = 'A'
    xians['C' + str(er + 1)].value = 'B'
    xians['D' + str(er + 1)].value = 'C'
    xians['E' + str(er + 1)].value = 'D'
    xians['A' + str(er + 2)].value = '第一学期'
    xians['B' + str(er + 2)].value = a
    xians['C' + str(er + 2)].value = b
    xians['D' + str(er + 2)].value = c
    xians['E' + str(er + 2)].value = d
    xians['A' + str(er + 3)].value = '第二学期'
    xians['B' + str(er + 3)].value = a1
    xians['C' + str(er + 3)].value = b1
    xians['D' + str(er + 3)].value = c1
    xians['E' + str(er + 3)].value = d1
    print('线下活动')
    print('第一学期')
    print(a_1, b_1, c_1, d_1)
    print('第二学期')
    print(a1_1, b1_1, c1_1, d1_1)

    er = int(len(xxia) / 5)
    xianx['A' + str(er + 1)].value = '学期'
    xianx['B' + str(er + 1)].value = 'A'
    xianx['C' + str(er + 1)].value = 'B'
    xianx['D' + str(er + 1)].value = 'C'
    xianx['E' + str(er + 1)].value = 'D'
    xianx['A' + str(er + 2)].value = '第一学期'
    xianx['B' + str(er + 2)].value = a_1
    xianx['C' + str(er + 2)].value = b_1
    xianx['D' + str(er + 2)].value = c_1
    xianx['E' + str(er + 2)].value = d_1
    xianx['A' + str(er + 3)].value = '第二学期'
    xianx['B' + str(er + 3)].value = a1_1
    xianx['C' + str(er + 3)].value = b1_1
    xianx['D' + str(er + 3)].value = c1_1
    xianx['E' + str(er + 3)].value = d1_1

    print("素质学分换算得分")
    print('第一学期：')
    print(xf(a + a_1, b + b_1, c + c_1, d + d_1))
    print('第二学期：')
    print(xf(a1 + a1_1, b1 + b1_1, c1 + c1_1, d1 + d1_1))
    workbook.save(filename=name + '线上.xlsx')
    workbook1.save(filename=name + '线下.xlsx')
    os.system('pause')

if __name__ == '__main__':
    print("请输入姓名：")
    name = input()
    print("请输入密码：")
    passs = input()
    schedule(name,passs)



    