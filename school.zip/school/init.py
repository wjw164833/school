from hoshino.service import Service
from .data import school
from nonebot import get_bot, scheduler
import os
import hoshino   
import datetime
import typing
from aiocqhttp.message import MessageSegment

sv = Service(
    '活动分数查询',
    enable_on_default=True,
    visible=True,
    help_="活动分数查询好帮手\n"
          ,
    bundle='查询活动分数'
)

cool_down = datetime.timedelta(minutes=3)  # 冷却时间
expire = datetime.timedelta(minutes=2)

temp = {}
last_check = {}


@sv.on_prefix(['查分', '活动分数查询', '查询活动分数'])
async def choose_song(bot, ev):
    key = f'{ev.group_id}-{ev.user_id}'
    if key not in temp:
        if str(ev.group_id) in last_check and datetime.datetime.now() - last_check[str(ev.group_id)] < expire:
            await bot.send(ev, '不可以替他人查询哦', at_sender=True)
        return
    song_dict = temp[key]
    song_idx = []
    for msg_seg in ev.message:
        if msg_seg.type == 'text' and msg_seg.data['text']:
            song_idx.append(msg_seg.data['text'].strip())
            String1,String2=song_idx.split()
            data.schedule(String1,String2)
            await bot.send_group_msg(ev.user_id,ev.group_id,message=f'[CQ:text,text=data.schedule(String1,String2)]')
    if not song_idx:
        await bot.send(ev, '请输入学号和密码,学号和密码请用空格隔开', at_sender=True)
   
        # else:
        #     await bot.send(ev, '只能选择列表中有的歌曲哦', at_sender=True)


